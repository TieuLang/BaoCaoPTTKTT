Báo cáo bao gồm:
	+ baocao_PTTKTT.pdf: Bản PDF của báo cáo
	+ source latex: Thư mục source latex của báo cáo.
	+ source code: Thư mục source code đã cài đặt cho bài toán, chứa các file mã nguồn thuật toán, mã nguồn phát sinh input, output, file thống kê số liệu, v.v...
	  (trong này có file README.md riêng mô tả chi tiết các thành phần của source code)
