Báo cáo bao gồm:
	+ baocao_PTTKTT.pdf: Bản PDF của báo cáo
	+ source latex: Thư mục source latex của báo cáo.
	+ source code: Thư mục source code đã cài đặt cho bài toán, chứa các file mã nguồn thuật toán, mã nguồn phát sinh input, output, file thống kê số liệu, v.v...
	  	
Trong sourcode có:
	Code_816E.py:  Mã nguồn cài đặt bài toán dùng làm báo cáo môn Phân tích thiết kế thuật toán, cũng là bài 816E trên Codeforces 

	Link đề bài trên codeforces: https://codeforces.com/problemset/problem/816/E hoặc https://codeforces.com/problemset/problem/815/C
	
	Code_de_quy.py: Mã đệ quy để kiểm tra tính chính xác của code, dùng trên các test nhỏ  
  
	Độ phức tạp không gian- Thực nghiệm.xlsx: File chứa các giá trị để kiểm tra độ phức tạp không gian bằng thực nghiệm  
  
	Độ phức tạp thời gian- Thực nghiệm.xlsx: File chứa các giá trị để kiểm tra độ phức tạp thời gian bằng thực nghiệm  

	Folder "Sinh file input": chứa tất cả các file cần cho việc sinh input  
  
    		- Code_816E-sinh_data.py: mã để sinh data, dùng trong việc kiểm tra độ phức tạp bằng thực nghiệm, được chỉnh sửa từ mã nguồn để giải bài toán 
      
    		- Tao_input.py: mã tạo input   
      
    		- Tonghop_input.py: mã tổng hợp các input được sinh ra từ file Tao_input.py 
     
    		- testcase.zip: file nén chứa các test case cho việc sinh data của file Code_816E-sinh_data.py  
 
	Hướng dẫn chạy:
  		- Chạy file Code_816E và nhập giá trị theo như đề bài.
  		- Để sinh dữ liệu để đánh giá độ phức tạp, bạn cần:
    			+ Giải nén tập testcase.zip vào project hoặc chạy file Tao_input.py để sinh ra input mới.
    			+ Sau đó, chạy file Code_816E-sinh_data.py để sinh ra file dpt.txt lưu độ phức tạp thực tế của từng test.